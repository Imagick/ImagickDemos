#!/bin/bash

    
#   req.url == "/int-en/syria" || req.url == "/int-en/syria/" || req.url ~ "^/int-en/syria\?"   || req.url ~ "^/int-en/syria/\?"  ||  

config_file=urls
if [ "X$1" != "X" ] ; then
    config_file=$1
fi
for url in `cat $config_file`
do
cat <<EOT
    req.url == "$url" || req.url == "$url/" || req.url ~ "^$url\?"   || req.url ~ "^$url/\?"  || 
EOT
done
